int f(int x) { return x >= 5; }
int g() { return 0; }
int main() {
  int a, b, c, d;
  int A[2];
  while (1 < 2) {}
  while (2 > 1);

  while ((a == b) && (c == d)) {
    while (a > 1) {
      a = a - 1;
    }
  }

  while (f(a) && !f(b)) {}
  while (!(f(a) + f(b)) && 1) {}
  while (1) {}
  while (a) {}
  while (g()) {}
  while (A[0] > A[1]) {}
}
