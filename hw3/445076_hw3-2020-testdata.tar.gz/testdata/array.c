int a[2];
int b[2][3];
int c[2][3][4];
int d[100000];
float x[2];
float y[1 + 2];
float z[1][2][3][5 * 6];

int main() {
  int local[3][4];
}
